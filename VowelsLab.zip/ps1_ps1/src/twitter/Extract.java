package twitter;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Extract {

    // Task 1: getTimespan
    public static Timespan getTimespan(List<Tweet> tweets) {
        if (tweets.isEmpty()) {
            throw new IllegalArgumentException("Tweet list cannot be empty");
        }

        Instant start = tweets.get(0).getTimestamp();
        Instant end = start;

        for (Tweet t : tweets) {
            Instant ts = t.getTimestamp();
            if (ts.isBefore(start)) {
                start = ts;
            }
            if (ts.isAfter(end)) {
                end = ts;
            }
        }

        return new Timespan(start, end);
    }

    public static Set<String> getMentionedUsers(List<Tweet> tweets) {
        Set<String> users = new HashSet<>();
        Pattern p = Pattern.compile("(?:^|[^A-Za-z0-9_])@([A-Za-z0-9_]+)");

        for (Tweet t : tweets) {
            Matcher m = p.matcher(t.getText());
            while (m.find()) {
                users.add(m.group(1).toLowerCase());
            }
        }
        return users;
    }

    }

